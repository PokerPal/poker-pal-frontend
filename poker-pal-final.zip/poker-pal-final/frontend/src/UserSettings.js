import logo from "./bluffBathLogo.png";
import React from "react";

export function UserSettings() {
    return (
        <div>
            USER SETTINGS PAGE
            {/*HTML HERE*/}
        </div>
    );
}